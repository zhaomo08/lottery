https://fouber.github.io/lottery/
抽奖程序，球状的特效